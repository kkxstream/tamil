<?php  
    
$date = date('d-m-y');
echo $date;

 
  
  
?>
